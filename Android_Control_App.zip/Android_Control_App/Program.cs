﻿using System;
using System.Windows.Forms;
using AndroidControlApp;  // ✅ Add this line

namespace LPW4006
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}
