﻿namespace AndroidControlApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Newly added controls
        private System.Windows.Forms.ComboBox comboBoxApps;
        private System.Windows.Forms.Button buttonRefresh;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            labelDevice = new Label();
            textBoxPackage = new TextBox();
            buttonReboot = new Button();
            buttonPowerOff = new Button();
            buttonShell = new Button();
            buttonListSdcard = new Button();
            buttonScreenshot = new Button();
            buttonInstall = new Button();
            buttonUninstall = new Button();
            comboBoxApps = new ComboBox();
            buttonRefresh = new Button();
            SuspendLayout();
            // 
            // labelDevice
            // 
            labelDevice.AutoSize = true;
            labelDevice.Location = new Point(12, 9);
            labelDevice.Name = "labelDevice";
            labelDevice.Size = new Size(140, 20);
            labelDevice.TabIndex = 0;
            labelDevice.Text = "Connected: (None)";
            // 
            // textBoxPackage
            // 
            textBoxPackage.Location = new Point(42, 343);
            textBoxPackage.Name = "textBoxPackage";
            textBoxPackage.PlaceholderText = "com.example.app";
            textBoxPackage.Size = new Size(250, 27);
            textBoxPackage.TabIndex = 8;
            // 
            // buttonReboot
            // 
            buttonReboot.Location = new Point(15, 39);
            buttonReboot.Name = "buttonReboot";
            buttonReboot.Size = new Size(120, 30);
            buttonReboot.TabIndex = 1;
            buttonReboot.Text = "Reboot";
            buttonReboot.UseVisualStyleBackColor = true;
            buttonReboot.Click += buttonReboot_Click;
            // 
            // buttonPowerOff
            // 
            buttonPowerOff.Location = new Point(350, 39);
            buttonPowerOff.Name = "buttonPowerOff";
            buttonPowerOff.Size = new Size(120, 30);
            buttonPowerOff.TabIndex = 2;
            buttonPowerOff.Text = "Power Off";
            buttonPowerOff.UseVisualStyleBackColor = true;
            buttonPowerOff.Click += buttonPowerOff_Click;
            // 
            // buttonShell
            // 
            buttonShell.BackgroundImageLayout = ImageLayout.Zoom;
            buttonShell.Location = new Point(115, 96);
            buttonShell.Name = "buttonShell";
            buttonShell.Size = new Size(250, 30);
            buttonShell.TabIndex = 3;
            buttonShell.Text = "Run Shell Command";
            buttonShell.UseVisualStyleBackColor = true;
            buttonShell.Click += buttonShell_Click;
            // 
            // buttonListSdcard
            // 
            buttonListSdcard.Location = new Point(115, 147);
            buttonListSdcard.Name = "buttonListSdcard";
            buttonListSdcard.Size = new Size(250, 30);
            buttonListSdcard.TabIndex = 4;
            buttonListSdcard.Text = "List /sdcard/";
            buttonListSdcard.UseVisualStyleBackColor = true;
            buttonListSdcard.Click += buttonListSdcard_Click;
            // 
            // buttonScreenshot
            // 
            buttonScreenshot.Location = new Point(115, 203);
            buttonScreenshot.Name = "buttonScreenshot";
            buttonScreenshot.Size = new Size(250, 30);
            buttonScreenshot.TabIndex = 5;
            buttonScreenshot.Text = "Take Screenshot";
            buttonScreenshot.UseVisualStyleBackColor = true;
            buttonScreenshot.Click += buttonScreenshot_Click;
            // 
            // buttonInstall
            // 
            buttonInstall.Location = new Point(115, 250);
            buttonInstall.Name = "buttonInstall";
            buttonInstall.Size = new Size(250, 30);
            buttonInstall.TabIndex = 6;
            buttonInstall.Text = "Install APK";
            buttonInstall.UseVisualStyleBackColor = true;
            buttonInstall.Click += buttonInstall_Click;
            // 
            // buttonUninstall
            // 
            buttonUninstall.Location = new Point(115, 388);
            buttonUninstall.Name = "buttonUninstall";
            buttonUninstall.Size = new Size(250, 30);
            buttonUninstall.TabIndex = 7;
            buttonUninstall.Text = "Uninstall App";
            buttonUninstall.UseVisualStyleBackColor = true;
            buttonUninstall.Click += buttonUninstall_Click;
            // 
            // comboBoxApps
            // 
            comboBoxApps.BackColor = Color.LightCyan;
            comboBoxApps.FormattingEnabled = true;
            comboBoxApps.Location = new Point(15, 298);
            comboBoxApps.Name = "comboBoxApps";
            comboBoxApps.Size = new Size(316, 28);
            comboBoxApps.TabIndex = 10;
            // 
            // buttonRefresh
            // 
            buttonRefresh.Location = new Point(350, 298);
            buttonRefresh.Name = "buttonRefresh";
            buttonRefresh.Size = new Size(120, 28);
            buttonRefresh.TabIndex = 11;
            buttonRefresh.Text = "Refresh";
            buttonRefresh.UseVisualStyleBackColor = true;
            buttonRefresh.Click += buttonRefresh_Click;
            // 
            // Form1
            // 
            BackColor = Color.Lavender;
            ClientSize = new Size(482, 453);
            Controls.Add(buttonRefresh);
            Controls.Add(comboBoxApps);
            Controls.Add(buttonUninstall);
            Controls.Add(buttonInstall);
            Controls.Add(buttonScreenshot);
            Controls.Add(buttonListSdcard);
            Controls.Add(buttonShell);
            Controls.Add(buttonPowerOff);
            Controls.Add(buttonReboot);
            Controls.Add(textBoxPackage);
            Controls.Add(labelDevice);
            Font = new Font("Segoe UI Variable Display Semib", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.DodgerBlue;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form1";
            Text = "Android ADB Controller";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label labelDevice;
        private System.Windows.Forms.TextBox textBoxPackage;
        private System.Windows.Forms.Button buttonReboot;
        private System.Windows.Forms.Button buttonPowerOff;
        private System.Windows.Forms.Button buttonShell;
        private System.Windows.Forms.Button buttonListSdcard;
        private System.Windows.Forms.Button buttonScreenshot;
        private System.Windows.Forms.Button buttonInstall;
        private System.Windows.Forms.Button buttonUninstall;
    }
}
