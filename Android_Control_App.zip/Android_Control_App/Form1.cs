using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace AndroidControlApp
{
    public partial class Form1 : Form
    {
        private string adbPath = "adb.exe";
        private string deviceSerial = "";

        public Form1()
        {
            InitializeComponent();
            CheckDeviceConnection();
            LoadInstalledApps(); 
        }
        private void LoadInstalledApps()
        {
            comboBoxApps.Items.Clear();
            string output = RunAdbCommand("shell pm list packages");
            var packages = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(p => p.Replace("package:", "").Trim())
                                .OrderBy(p => p);

            foreach (var package in packages)
            {
                comboBoxApps.Items.Add(package);
            }
        }

        // Check if device is connected
        private void CheckDeviceConnection()
        {
            string output = RunAdbCommand("devices");
            string[] lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            // Look for "device" status
            var deviceLine = lines.FirstOrDefault(line => line.EndsWith("device"));
            if (deviceLine != null)
            {
                deviceSerial = deviceLine.Split('\t')[0];
                labelDevice.Text = $"Connected: {deviceSerial}";
            }
            else
            {
                labelDevice.Text = "No device connected!";
                MessageBox.Show("Connect your Android device and authorize USB debugging.");
            }
        }

        // Generic method to run ADB commands
        private string RunAdbCommand(string arguments)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = adbPath,
                    Arguments = arguments,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = new Process { StartInfo = psi })
                {
                    process.Start();
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    if (!string.IsNullOrEmpty(error))
                        throw new Exception($"ADB Error: {error}");

                    return output;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed: {ex.Message}");
                return "";
            }
        }

        // --- Button Click Events (Revised) ---
        private void buttonReboot_Click(object sender, EventArgs e)
        {
            RunAdbCommand("reboot");
            MessageBox.Show("Device rebooting...");
        }

        private void buttonPowerOff_Click(object sender, EventArgs e)
        {
            RunAdbCommand("shell reboot -p"); // Power off
            MessageBox.Show("Device is powering off...");
        }

        private void buttonShell_Click(object sender, EventArgs e)
        {
            string result = RunAdbCommand("shell echo HelloFromDevice");
            MessageBox.Show("Shell Output:\n" + result);
        }

        private void buttonListSdcard_Click(object sender, EventArgs e)
        {
            string result = RunAdbCommand("shell ls /sdcard/");
            MessageBox.Show("SDCard Contents:\n" + result);
        }

        private void buttonScreenshot_Click(object sender, EventArgs e)
        {
            try
            {
                string deviceScreenshotPath = "/sdcard/screenshot.png";
                string localScreenshotPath = Path.Combine(Environment.CurrentDirectory, "screenshot.png");

                // Step 1: Take screenshot on phone
                RunAdbCommand($"shell screencap -p {deviceScreenshotPath}");

                // Step 2: Pull screenshot to PC
                RunAdbCommand($"pull {deviceScreenshotPath} \"{localScreenshotPath}\"");

                // Step 3: Optional - delete screenshot from phone
                RunAdbCommand($"shell rm {deviceScreenshotPath}");

                MessageBox.Show("Screenshot saved to:\n" + localScreenshotPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void buttonInstall_Click(object sender, EventArgs e)
        {
            using OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "APK files (*.apk)|*.apk";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                var result = RunAdbCommand($"install \"{dlg.FileName}\"");
                if (result.Contains("Success"))
                {
                    MessageBox.Show("APK installed successfully!");
                    LoadInstalledApps(); // Refresh app list
                }
                else
                {
                    MessageBox.Show($"Install failed:\n{result}");
                }
            }
        }
        private void buttonUninstall_Click(object sender, EventArgs e)
        {
            if (comboBoxApps.SelectedItem == null)
            {
                MessageBox.Show("Please select an app from the list");
                return;
            }

            string packageName = comboBoxApps.SelectedItem.ToString();
            var result = RunAdbCommand($"uninstall {packageName}");

            if (result.Contains("Success"))
            {
                MessageBox.Show("App uninstalled successfully!");
                LoadInstalledApps(); // Refresh app list
            }
            else
            {
                MessageBox.Show($"Uninstall failed:\n{result}");
            }
        }
        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            LoadInstalledApps();
            MessageBox.Show("App list refreshed!");
        }
    }
}